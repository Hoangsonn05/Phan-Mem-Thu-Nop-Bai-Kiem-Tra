using System.IO.Compression;
using System.Text;
using System.Text.Json;
using ExamTransfer.Application;
using ExamTransfer.Domain;
using ExamTransfer.Infrastructure.Persistence;
using ExamTransfer.Infrastructure.Services;
using ExamTransfer.LocalServer.Controllers;
using ExamTransfer.Shared.Contracts;
using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;
using Xunit;

namespace ExamTransfer.Infrastructure.Tests;

public sealed class QuizDocumentImportTests
{
    [Fact]
    public async Task DocxPreview_DoesNotMutate_CommitIsOwnedOneUseAndReplaceExplicit()
    {
        await using var fixture = await Fixture.CreateAsync();
        var teacher = Guid.NewGuid();
        var bytes = Docx(
            "1_1_1: Thủ đô Việt Nam?",
            "A. Hà Nội",
            "B. Huế",
            "C. Đà Nẵng",
            "D. Thành phố Hồ Chí Minh",
            "Đáp án đúng: A. Hà Nội",
            "Câu 2: Số chẵn?",
            "A) 2",
            "B) 3",
            "C) 4",
            "Đáp án đúng: A; C");

        var preview = await fixture.Service.PreviewImportAsync(
            fixture.Exam.Id,
            teacher,
            new("nguon-de.docx", Convert.ToBase64String(bytes)),
            default);

        Assert.Empty(preview.Errors);
        Assert.Equal(2, preview.QuestionCount);
        Assert.False(preview.WillReplaceExisting);
        Assert.Empty(await fixture.Db.QuizQuestionsSet.ToListAsync());
        Assert.Empty(await fixture.Db.QuizImportSourcesSet.ToListAsync());
        Assert.Empty(await fixture.Db.SyncQueueSet.ToListAsync());

        var forbidden = await Assert.ThrowsAsync<ApiException>(() =>
            fixture.Service.CommitImportAsync(
                fixture.Exam.Id,
                Guid.NewGuid(),
                new(preview.PreviewToken, false, fixture.Exam.RowVersion),
                default));
        Assert.Equal(403, forbidden.StatusCode);

        var committed = await fixture.Service.CommitImportAsync(
            fixture.Exam.Id,
            teacher,
            new(preview.PreviewToken, false, fixture.Exam.RowVersion),
            default);
        Assert.Equal(2, committed.QuestionCount);
        Assert.Equal(2, await fixture.Db.QuizQuestionsSet.CountAsync());
        var source = await fixture.Db.QuizImportSourcesSet.SingleAsync();
        var sourceId = source.Id;
        var firstSourcePath = Path.Combine(fixture.Paths.RootPath, source.RelativePath);
        Assert.Equal("nguon-de.docx", source.OriginalName);
        Assert.Equal(teacher, source.CreatedBy);
        Assert.True(File.Exists(firstSourcePath));

        await Assert.ThrowsAsync<ApiException>(() => fixture.Service.CommitImportAsync(
            fixture.Exam.Id,
            teacher,
            new(preview.PreviewToken, false, fixture.Exam.RowVersion),
            default));

        var replacement = await fixture.Service.PreviewImportAsync(
            fixture.Exam.Id,
            teacher,
            new("thay-the.docx", Convert.ToBase64String(Docx(
                "1. Câu thay thế?",
                "A. Đúng",
                "B. Sai",
                "Đáp án đúng: A. Đúng"))),
            default);
        Assert.True(replacement.WillReplaceExisting);
        await Assert.ThrowsAsync<ApiException>(() => fixture.Service.CommitImportAsync(
            fixture.Exam.Id,
            teacher,
            new(replacement.PreviewToken, false, fixture.Exam.RowVersion),
            default));
        Assert.Equal(2, await fixture.Db.QuizQuestionsSet.CountAsync());

        var replaced = await fixture.Service.CommitImportAsync(
            fixture.Exam.Id,
            teacher,
            new(replacement.PreviewToken, true, fixture.Exam.RowVersion),
            default);
        Assert.Equal(1, replaced.QuestionCount);
        Assert.Single(await fixture.Db.QuizQuestionsSet.ToListAsync());
        var secondSource = await fixture.Db.QuizImportSourcesSet.SingleAsync();
        var secondSourcePath = Path.Combine(fixture.Paths.RootPath, secondSource.RelativePath);
        Assert.Equal(sourceId, secondSource.Id);
        Assert.Equal("thay-the.docx", secondSource.OriginalName);
        Assert.False(File.Exists(firstSourcePath));
        Assert.True(File.Exists(secondSourcePath));

        var thirdPreview = await fixture.Service.PreviewImportAsync(
            fixture.Exam.Id,
            teacher,
            new("thay-the-lan-ba.docx", Convert.ToBase64String(Docx(
                "1. Câu thay thế lần ba?",
                "A. Đúng",
                "B. Sai",
                "Đáp án đúng: B. Sai"))),
            default);
        await fixture.Service.CommitImportAsync(
            fixture.Exam.Id,
            teacher,
            new(thirdPreview.PreviewToken, true, fixture.Exam.RowVersion),
            default);

        var thirdSource = await fixture.Db.QuizImportSourcesSet.SingleAsync();
        var thirdSourcePath = Path.Combine(fixture.Paths.RootPath, thirdSource.RelativePath);
        Assert.Equal(sourceId, thirdSource.Id);
        Assert.Equal("thay-the-lan-ba.docx", thirdSource.OriginalName);
        Assert.False(File.Exists(secondSourcePath));
        Assert.True(File.Exists(thirdSourcePath));

        var sourceOutbox = Assert.Single(await fixture.Db.SyncQueueSet
            .Where(x => x.EntityType == "quiz_import_sources" && x.Operation == "upsert")
            .ToListAsync());
        Assert.Equal(sourceId.ToString(), sourceOutbox.EntityId);
        Assert.Equal(thirdSourcePath, sourceOutbox.FilePath);
    }

    [Fact]
    public async Task ReplaceRollback_RetainsStableSourceAndOldFile()
    {
        await using var fixture = await Fixture.CreateAsync();
        var teacher = Guid.NewGuid();
        var initial = await fixture.Service.PreviewImportAsync(
            fixture.Exam.Id,
            teacher,
            new("initial.docx", Convert.ToBase64String(Docx(
                "1. Câu ban đầu?",
                "A. Đúng",
                "B. Sai",
                "Đáp án đúng: A"))),
            default);
        await fixture.Service.CommitImportAsync(
            fixture.Exam.Id,
            teacher,
            new(initial.PreviewToken, false, fixture.Exam.RowVersion),
            default);
        var original = await fixture.Db.QuizImportSourcesSet.AsNoTracking().SingleAsync();
        var originalPath = Path.Combine(fixture.Paths.RootPath, original.RelativePath);

        var replacement = await fixture.Service.PreviewImportAsync(
            fixture.Exam.Id,
            teacher,
            new("replacement.docx", Convert.ToBase64String(Docx(
                "1. Câu thay thế?",
                "A. Một",
                "B. Hai",
                "Đáp án đúng: B"))),
            default);
        var failing = new QuizService(
            fixture.Db,
            new FailingSourceOutbox(new OutboxService(fixture.Db)),
            fixture.Paths);

        await Assert.ThrowsAsync<IOException>(() => failing.CommitImportAsync(
            fixture.Exam.Id,
            teacher,
            new(replacement.PreviewToken, true, fixture.Exam.RowVersion),
            default));

        fixture.Db.ChangeTracker.Clear();
        var retained = await fixture.Db.QuizImportSourcesSet.AsNoTracking().SingleAsync();
        Assert.Equal(original.Id, retained.Id);
        Assert.Equal(original.OriginalName, retained.OriginalName);
        Assert.Equal(original.RelativePath, retained.RelativePath);
        Assert.True(File.Exists(originalPath));
        Assert.Equal(
            [originalPath],
            Directory.GetFiles(Path.GetDirectoryName(originalPath)!).OrderBy(x => x).ToArray());
    }

    [Fact]
    public async Task LegacyImportEndpoint_IsGoneAndDoesNotMutateQuiz()
    {
        await using var fixture = await Fixture.CreateAsync();
        var document = new QuizImportDocument(
        [
            new QuizImportQuestion(
                "Legacy question",
                1,
                false,
                ["A", "B"],
                [0])
        ]);
        var request = new QuizImportFileRequest(
            "legacy.json",
            Convert.ToBase64String(JsonSerializer.SerializeToUtf8Bytes(
                document,
                new JsonSerializerOptions(JsonSerializerDefaults.Web))));
        var controller = new QuizAuthoringController(fixture.Service);

        var error = await Assert.ThrowsAsync<ApiException>(() =>
            controller.Import(fixture.Exam.Id, request, default));

        Assert.Equal(410, error.StatusCode);
        Assert.Equal(ErrorCodes.QuizImportLegacyDisabled, error.Code);
        Assert.Empty(await fixture.Db.QuizQuestionsSet.ToListAsync());
        Assert.Empty(await fixture.Db.QuizImportSourcesSet.ToListAsync());
        Assert.Empty(await fixture.Db.SyncQueueSet.ToListAsync());
    }

    [Theory]
    [InlineData("ANSWER_MISSING", "1. Thiếu đáp án?", "A. Một", "B. Hai")]
    [InlineData("ANSWER_TEXT_MISMATCH", "1. Sai nội dung?", "A. Một", "B. Hai", "Đáp án đúng: A. Không khớp")]
    [InlineData("DUPLICATE_CHOICE", "1. Trùng lựa chọn?", "A. Một", "A. Hai", "B. Ba", "Đáp án đúng: B")]
    [InlineData("ANSWER_UNKNOWN_CHOICE", "1. Nhãn không tồn tại?", "A. Một", "B. Hai", "Đáp án đúng: C")]
    public async Task DocxPreview_ReportsStructuredValidationErrors(string expectedCode, params string[] lines)
    {
        await using var fixture = await Fixture.CreateAsync();
        var preview = await fixture.Service.PreviewImportAsync(
            fixture.Exam.Id,
            Guid.NewGuid(),
            new("invalid.docx", Convert.ToBase64String(Docx(lines))),
            default);

        Assert.Contains(preview.Errors, x => x.Code == expectedCode);
        Assert.True(string.IsNullOrEmpty(preview.PreviewToken));
        Assert.Empty(await fixture.Db.QuizQuestionsSet.ToListAsync());
    }

    [Fact]
    public async Task PdfWithoutTextLayer_IsRejectedWithoutOcrFallback()
    {
        await using var fixture = await Fixture.CreateAsync();
        var preview = await fixture.Service.PreviewImportAsync(
            fixture.Exam.Id,
            Guid.NewGuid(),
            new("scan.pdf", Convert.ToBase64String(BlankPdf())),
            default);

        var error = Assert.Single(preview.Errors);
        Assert.Equal("DOCUMENT_INVALID", error.Code);
        Assert.Contains("không có lớp văn bản", error.Message, StringComparison.OrdinalIgnoreCase);
    }

    private static byte[] Docx(params string[] lines)
    {
        using var output = new MemoryStream();
        using (var archive = new ZipArchive(output, ZipArchiveMode.Create, leaveOpen: true))
        {
            var entry = archive.CreateEntry("word/document.xml");
            using var writer = new StreamWriter(entry.Open(), new UTF8Encoding(false));
            writer.Write(
                "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
                "<w:document xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\"><w:body>");
            foreach (var line in lines)
                writer.Write($"<w:p><w:r><w:t>{System.Security.SecurityElement.Escape(line)}</w:t></w:r></w:p>");
            writer.Write("</w:body></w:document>");
        }
        return output.ToArray();
    }

    private static byte[] BlankPdf()
    {
        var objects = new[]
        {
            "<< /Type /Catalog /Pages 2 0 R >>",
            "<< /Type /Pages /Kids [3 0 R] /Count 1 >>",
            "<< /Type /Page /Parent 2 0 R /MediaBox [0 0 200 200] /Resources << >> /Contents 4 0 R >>",
            "<< /Length 0 >>\nstream\n\nendstream"
        };
        var builder = new StringBuilder("%PDF-1.4\n");
        var offsets = new List<int> { 0 };
        for (var index = 0; index < objects.Length; index++)
        {
            offsets.Add(Encoding.ASCII.GetByteCount(builder.ToString()));
            builder.Append(index + 1).Append(" 0 obj\n").Append(objects[index]).Append("\nendobj\n");
        }
        var xref = Encoding.ASCII.GetByteCount(builder.ToString());
        builder.Append("xref\n0 5\n0000000000 65535 f \n");
        foreach (var offset in offsets.Skip(1))
            builder.Append(offset.ToString("D10")).Append(" 00000 n \n");
        builder.Append("trailer\n<< /Size 5 /Root 1 0 R >>\nstartxref\n")
            .Append(xref).Append("\n%%EOF\n");
        return Encoding.ASCII.GetBytes(builder.ToString());
    }

    private sealed class Fixture : IAsyncDisposable
    {
        private readonly SqliteConnection connection;
        private Fixture(SqliteConnection connection, AppDbContext db, Paths paths, Exam exam)
        {
            this.connection = connection;
            Db = db;
            Paths = paths;
            Exam = exam;
            Service = new QuizService(db, new OutboxService(db), paths);
        }

        public AppDbContext Db { get; }
        public Paths Paths { get; }
        public Exam Exam { get; }
        public QuizService Service { get; }

        public static async Task<Fixture> CreateAsync()
        {
            var connection = new SqliteConnection("Data Source=:memory:");
            await connection.OpenAsync();
            var db = new AppDbContext(
                new DbContextOptionsBuilder<AppDbContext>().UseSqlite(connection).Options);
            await db.Database.EnsureCreatedAsync();
            var exam = new Exam
            {
                Title = "Quiz",
                Subject = "Test",
                Status = ExamStatus.Draft,
                DeliveryType = ExamDeliveryType.MultipleChoice,
                SupervisionMode = SupervisionMode.Standard,
                QuizResultPolicy = QuizResultPolicy.Hidden
            };
            db.ExamsSet.Add(exam);
            await db.SaveChangesAsync();
            var paths = new Paths(Path.Combine(
                Path.GetTempPath(),
                "ExamTransfer.QuizImportTests",
                Guid.NewGuid().ToString("N")));
            paths.EnsureCreated();
            return new(connection, db, paths, exam);
        }

        public async ValueTask DisposeAsync()
        {
            await Db.DisposeAsync();
            await connection.DisposeAsync();
            if (Directory.Exists(Paths.RootPath))
                Directory.Delete(Paths.RootPath, recursive: true);
        }
    }

    private sealed class FailingSourceOutbox(IOutboxService inner) : IOutboxService
    {
        public Task EnqueueAsync(
            string entityType,
            string entityId,
            string operation,
            object payload,
            string? filePath = null,
            CancellationToken cancellationToken = default)
        {
            if (string.Equals(entityType, "quiz_import_sources", StringComparison.OrdinalIgnoreCase))
                throw new IOException("Simulated source outbox failure.");
            return inner.EnqueueAsync(entityType, entityId, operation, payload, filePath, cancellationToken);
        }
    }

    public sealed class Paths(string root) : IStoragePaths
    {
        public string RootPath { get; } = root;
        public string DatabasePath => Path.Combine(RootPath, "database", "exam-transfer.db");
        public string BackupRoot => Path.Combine(RootPath, "backups");
        public string ExportRoot => Path.Combine(RootPath, "exports");
        public string TemporaryRoot => Path.Combine(RootPath, "temporary");
        public string ExamVersionRoot(Guid examId, int version) => Path.Combine(RootPath, "exams", examId.ToString("N"), $"v{version}");
        public string SessionRoot(Guid sessionId) => Path.Combine(RootPath, "sessions", sessionId.ToString("N"));
        public string SubmissionRoot(Guid sessionId, string studentCode, Guid submissionId) => Path.Combine(SessionRoot(sessionId), studentCode, submissionId.ToString("N"));
        public string ReceiptRoot(Guid sessionId) => Path.Combine(SessionRoot(sessionId), "receipts");
        public void EnsureCreated()
        {
            Directory.CreateDirectory(Path.GetDirectoryName(DatabasePath)!);
            Directory.CreateDirectory(BackupRoot);
            Directory.CreateDirectory(ExportRoot);
            Directory.CreateDirectory(TemporaryRoot);
        }
    }
}
