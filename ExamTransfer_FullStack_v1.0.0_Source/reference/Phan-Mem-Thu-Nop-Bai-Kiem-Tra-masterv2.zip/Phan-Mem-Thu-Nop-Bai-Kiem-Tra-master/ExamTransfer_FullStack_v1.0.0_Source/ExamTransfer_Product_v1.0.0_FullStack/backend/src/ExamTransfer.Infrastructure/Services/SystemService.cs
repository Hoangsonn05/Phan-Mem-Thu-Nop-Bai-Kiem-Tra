﻿using System.Reflection;
using System.Text.Json;
using ExamTransfer.Application;
using ExamTransfer.Domain;
using ExamTransfer.Infrastructure.Backup;
using ExamTransfer.Infrastructure.Persistence;
using ExamTransfer.Shared.Contracts;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;

namespace ExamTransfer.Infrastructure.Services;

public sealed class SystemService(AppDbContext db, IStoragePaths paths, ICloudAdapter cloud, IOptions<ExamTransferOptions> options, IRealtimePublisher realtime) : ISystemService
{
    private readonly ExamTransferOptions _options = options.Value;
    private const string SettingsKey = "runtime.settings";

    public async Task<SystemStatusDto> GetStatusAsync(CancellationToken cancellationToken)
    {
        var warnings = new List<string>();
        var dbStatus = "Ready";
        try { _ = await db.Database.ExecuteSqlRawAsync("SELECT 1;", cancellationToken); }
        catch (Exception ex) { dbStatus = "Error"; warnings.Add("Database: " + ex.Message); }
        paths.EnsureCreated();
        var drive = new DriveInfo(Path.GetPathRoot(paths.RootPath)!); var free = drive.AvailableFreeSpace;
        var storageStatus = free < _options.Storage.MinFreeBytes ? "LowDisk" : "Ready";
        if (storageStatus == "LowDisk") warnings.Add("Dung lượng ổ đĩa thấp hơn ngưỡng an toàn.");
        var cloudPreflight = await cloud.PreflightAsync(cancellationToken);
        var cloudStatus = !_options.Cloud.Enabled
            ? "Disabled"
            : !cloudPreflight.Configured
                ? "Misconfigured"
                : !cloudPreflight.CanSynchronize
                    ? "AuthenticationRequired"
                    : cloudPreflight.Reachable
                        ? "Online"
                        : "Offline";
        if (_options.Cloud.Enabled && !cloudPreflight.Configured)
            warnings.AddRange(cloudPreflight.Errors);
        else if (_options.Cloud.Enabled
            && cloudStatus == "AuthenticationRequired")
            warnings.Add("Cần đăng nhập Supabase để đồng bộ; luồng LAN vẫn hoạt động.");
        else if (_options.Cloud.Enabled && cloudStatus == "Offline")
            warnings.Add("Cloud đang ngoại tuyến; luồng LAN vẫn hoạt động.");
        return new SystemStatusDto(dbStatus == "Ready" && storageStatus == "Ready", Version(), DateTimeOffset.UtcNow, dbStatus, storageStatus, free, _options.Discovery.Enabled ? "Enabled" : "Disabled", cloudStatus, warnings);
    }

    public Task<SystemStatusDto> PreflightAsync(CancellationToken cancellationToken) => GetStatusAsync(cancellationToken);

    public async Task<object> GetDiagnosticsAsync(CancellationToken cancellationToken)
    {
        var status = await GetStatusAsync(cancellationToken);
        var schema = await db.AppSettingsSet.AsNoTracking().FirstOrDefaultAsync(x => x.Key == "schema.version", cancellationToken);
        return new { status, schemaVersion = schema?.ValueJson, process = new { Environment.ProcessId, Environment.MachineName, Environment.OSVersion, baseDirectory = AppContext.BaseDirectory }, paths = new { root = paths.RootPath, database = paths.DatabasePath }, configuration = new { server = new { _options.Server.Port, _options.Server.UseHttps }, discovery = new { _options.Discovery.Enabled, _options.Discovery.Port }, transfer = new { _options.Transfer.ChunkSizeBytes, _options.Transfer.MaxConcurrentUploads }, cloud = new { _options.Cloud.Enabled, _options.Cloud.Environment, _options.Cloud.SupabaseUrl, _options.Cloud.OrganizationId, publishableKeyConfigured = !string.IsNullOrWhiteSpace(_options.Cloud.EffectivePublishableKey), secretKeyConfigured = !string.IsNullOrWhiteSpace(_options.Cloud.ResolveSecretKey()), _options.Cloud.UseResumableUploads, _options.Cloud.AccessMode, authenticated = cloud.Authenticated, authenticatedEmail = cloud.CurrentSession?.Email, canSynchronize = cloud.CanSynchronize }, backupEncryptionConfigured = !string.IsNullOrWhiteSpace(Environment.GetEnvironmentVariable(BackupCrypto.KeyEnvironmentVariable)), runtimeSettingsPath = RuntimeConfiguration.ConfigurationPath } };
    }

    public async Task<DashboardSummaryDto> GetDashboardAsync(CancellationToken cancellationToken)
    {
        var classes = await db.ClassesSet.CountAsync(x => x.Status == ClassStatus.Active, cancellationToken);
        var exams = await db.ExamsSet.CountAsync(x => x.Status != ExamStatus.Archived, cancellationToken);
        var active = await db.ExamSessionsSet.CountAsync(x => x.Status == SessionStatus.Waiting || x.Status == SessionStatus.InProgress || x.Status == SessionStatus.Paused || x.Status == SessionStatus.Collecting, cancellationToken);
        var pending = await db.SubmissionsSet.CountAsync(x => x.IsOfficial && (x.Status == SubmissionStatus.Submitted || x.Status == SubmissionStatus.LateSubmitted) && !db.GradesSet.Any(g => g.SubmissionId == x.Id), cancellationToken);
        var recentKeys = await db.ExamSessionsSet
            .AsNoTracking()
            .Select(x => new { x.Id, x.UpdatedAtUtc })
            .ToListAsync(cancellationToken);
        var recentIds = recentKeys
            .OrderByDescending(x => x.UpdatedAtUtc)
            .ThenByDescending(x => x.Id)
            .Take(5)
            .Select(x => x.Id)
            .ToList();
        var recentEntities = recentIds.Count == 0
            ? []
            : await db.ExamSessionsSet
                .AsNoTracking()
                .Include(x => x.Exam)
                .Include(x => x.Participants)
                .Where(x => recentIds.Contains(x.Id))
                .ToListAsync(cancellationToken);
        var recentPositions = recentIds
            .Select((id, index) => new { id, index })
            .ToDictionary(x => x.id, x => x.index);
        var recent = recentEntities
            .OrderBy(x => recentPositions[x.Id])
            .Select(x => new SessionSummaryDto(x.Id, x.ExamId, x.Exam.Title, x.RoomCode, x.Status, DateTimeOffset.UtcNow, x.StartedAtUtc, x.EndedAtUtc, x.StartedAtUtc?.AddMinutes(x.Exam.DurationMinutes), new SessionCountsDto(x.Participants.Count, x.Participants.Count(p => p.Status == ParticipantStatus.PendingApproval), x.Participants.Count(p => p.Status == ParticipantStatus.Approved), x.Participants.Count(p => p.LastSeenUtc > DateTimeOffset.UtcNow.AddSeconds(-_options.Session.DisconnectAfterSeconds)), x.Participants.Count(p => p.SubmissionStatus is SubmissionStatus.Submitted or SubmissionStatus.LateSubmitted), x.Participants.Count(p => p.SubmissionStatus == SubmissionStatus.Uploading), x.Participants.Count(p => p.Status == ParticipantStatus.Disconnected)), x.Sequence, x.RowVersion))
            .ToList();
        long storage = 0; try { storage = Directory.EnumerateFiles(paths.RootPath, "*", SearchOption.AllDirectories).Sum(f => new FileInfo(f).Length); } catch { }
        var status = await GetStatusAsync(cancellationToken);
        return new DashboardSummaryDto(classes, exams, active, pending, storage, recent, status.Warnings);
    }

    public async Task<SettingsDto> GetSettingsAsync(CancellationToken cancellationToken)
    {
        var stored = await db.AppSettingsSet.AsNoTracking().FirstOrDefaultAsync(x => x.Key == SettingsKey, cancellationToken);
        if (stored is not null)
        {
            try
            {
                var parsed = JsonSerializer.Deserialize<SettingsDto>(
                    stored.ValueJson,
                    new JsonSerializerOptions(JsonSerializerDefaults.Web));
                if (parsed is not null)
                {
                    return OverlayCloudRuntime(
                        parsed with { RowVersion = stored.RowVersion });
                }
            }
            catch
            {
                // Fall back to current runtime configuration.
            }
        }
        return Defaults(stored?.RowVersion ?? "new");
    }

    public async Task<SettingsDto> UpdateSettingsAsync(UpdateSettingsRequest request, CancellationToken cancellationToken)
    {
        Validate(request);
        var cloudIdentityChanged =
            !string.Equals(
                request.SupabaseUrl?.TrimEnd('/'),
                _options.Cloud.SupabaseUrl?.TrimEnd('/'),
                StringComparison.OrdinalIgnoreCase)
            || !string.Equals(
                request.SupabasePublishableKey,
                _options.Cloud.EffectivePublishableKey,
                StringComparison.Ordinal)
            || !string.Equals(
                request.OrganizationId,
                _options.Cloud.OrganizationId,
                StringComparison.OrdinalIgnoreCase)
            || !string.Equals(
                request.CloudAccessMode,
                _options.Cloud.AccessMode,
                StringComparison.OrdinalIgnoreCase);

        if (cloudIdentityChanged && cloud.Authenticated)
            await cloud.LogoutAsync(cancellationToken);

        var active = await db.ExamSessionsSet.AnyAsync(x => x.Status == SessionStatus.Waiting || x.Status == SessionStatus.InProgress || x.Status == SessionStatus.Paused || x.Status == SessionStatus.Collecting, cancellationToken);
        if (active && (request.ServerPort != _options.Server.Port || request.StorageRootPath != paths.RootPath || request.ChunkSizeBytes != _options.Transfer.ChunkSizeBytes)) throw new ApiException(ErrorCodes.Conflict, "Không đổi cổng, đường dẫn hoặc chunk size khi phòng thi đang hoạt động.", 409);
        var entity = await db.AppSettingsSet.FirstOrDefaultAsync(x => x.Key == SettingsKey, cancellationToken);
        if (entity is null) { entity = new AppSetting { Key = SettingsKey }; db.AppSettingsSet.Add(entity); }
        else if (request.RowVersion != "new" && entity.RowVersion != request.RowVersion) throw new ApiException(ErrorCodes.ConcurrencyConflict, "Cài đặt đã thay đổi.", 409);
        var dto = new SettingsDto(
            request.ServerPort,
            request.UseHttps,
            request.DiscoveryEnabled,
            request.DiscoveryPort,
            request.StorageRootPath,
            request.MinFreeBytes,
            request.ChunkSizeBytes,
            request.MaxConcurrentUploads,
            request.HeartbeatSeconds,
            request.DisconnectAfterSeconds,
            request.CloudEnabled,
            request.TemporaryHours,
            request.LogsDays,
            entity.RowVersion,
            request.SupabaseUrl,
            request.SupabasePublishableKey,
            request.OrganizationId,
            request.CloudEnvironment,
            request.CloudUseResumableUploads,
            !string.IsNullOrWhiteSpace(_options.Cloud.ResolveSecretKey()),
            request.CloudEnabled
                ? cloudIdentityChanged
                    && string.Equals(
                        request.CloudAccessMode,
                        CloudAccessModes.UserSession,
                        StringComparison.OrdinalIgnoreCase)
                    ? "AuthenticationRequired"
                    : "PendingPreflight"
                : "Disabled",
            request.CloudAccessMode,
            cloud.Authenticated,
            cloud.CurrentSession?.Email);
        RuntimeConfiguration.Save(request);
        entity.ValueJson = JsonSerializer.Serialize(dto, new JsonSerializerOptions(JsonSerializerDefaults.Web));
        await db.SaveChangesAsync(cancellationToken);

        _options.Server.Port = request.ServerPort;
        _options.Server.UseHttps = request.UseHttps;
        _options.Discovery.Enabled = request.DiscoveryEnabled;
        _options.Discovery.Port = request.DiscoveryPort;
        _options.Storage.RootPath = request.StorageRootPath;
        _options.Storage.MinFreeBytes = request.MinFreeBytes;
        _options.Transfer.ChunkSizeBytes = request.ChunkSizeBytes;
        _options.Transfer.MaxConcurrentUploads = request.MaxConcurrentUploads;
        _options.Session.HeartbeatSeconds = request.HeartbeatSeconds;
        _options.Session.DisconnectAfterSeconds = request.DisconnectAfterSeconds;
        _options.Cloud.Enabled = request.CloudEnabled;
        _options.Cloud.SupabaseUrl = request.SupabaseUrl;
        _options.Cloud.PublishableKey = request.SupabasePublishableKey;
        _options.Cloud.OrganizationId = request.OrganizationId;
        _options.Cloud.Environment = request.CloudEnvironment;
        _options.Cloud.UseResumableUploads = request.CloudUseResumableUploads;
        _options.Cloud.AccessMode = request.CloudAccessMode;
        _options.Retention.TemporaryHours = request.TemporaryHours;
        _options.Retention.LogsDays = request.LogsDays;

        dto = dto with { RowVersion = entity.RowVersion };
        await realtime.PublishSessionAsync(Guid.Empty, RealtimeEvents.SettingsChanged, 0, dto, cancellationToken);
        return dto;
    }

    public async Task<CloudSyncStatusDto> GetCloudStatusAsync(CancellationToken cancellationToken)
    {
        var pending = await db.SyncQueueSet.CountAsync(x => x.Status == SyncStatus.Pending || x.Status == SyncStatus.Failed, cancellationToken);
        var failed = await db.SyncQueueSet.OrderByDescending(x => x.UpdatedAtUtc).FirstOrDefaultAsync(x => x.Status == SyncStatus.Failed, cancellationToken);
        var success = await db.SyncQueueSet.Where(x => x.Status == SyncStatus.Synced).OrderByDescending(x => x.UpdatedAtUtc).Select(x => (DateTimeOffset?)x.UpdatedAtUtc).FirstOrDefaultAsync(cancellationToken);
        var preflight = await cloud.PreflightAsync(cancellationToken);
        return new CloudSyncStatusDto(
            _options.Cloud.Enabled,
            !_options.Cloud.Enabled
                ? SyncStatus.LocalOnly
                : !preflight.Configured
                    ? SyncStatus.Failed
                    : !preflight.CanSynchronize
                        ? SyncStatus.Pending
                        : failed is not null
                            ? SyncStatus.Failed
                            : pending > 0
                                ? SyncStatus.Pending
                                : SyncStatus.Synced,
            pending,
            success,
            failed?.LastError
                ?? preflight.Errors.FirstOrDefault()
                ?? (!preflight.CanSynchronize
                    ? "Cần đăng nhập Supabase bằng tài khoản Admin/Teacher thuộc đúng organization."
                    : null),
            preflight.Configured,
            preflight.OrganizationId,
            preflight.UploadStrategy,
            preflight.AccessMode,
            preflight.Authenticated,
            preflight.CanSynchronize);
    }

    public async Task TriggerCloudSyncAsync(CancellationToken cancellationToken)
    {
        if (!_options.Cloud.Enabled)
            throw new ApiException(ErrorCodes.CloudOffline, "Cloud chưa được bật.", 503);
        var preflight = await cloud.PreflightAsync(cancellationToken);
        if (!preflight.CanSynchronize)
            throw new ApiException(
                preflight.Configured
                    ? ErrorCodes.Unauthorized
                    : ErrorCodes.CloudOffline,
                preflight.Configured
                    ? "Cần đăng nhập Supabase trước khi đồng bộ."
                    : "Cấu hình Supabase chưa hoàn chỉnh.",
                preflight.Configured ? 401 : 503,
                details: preflight.Errors.Concat(preflight.Warnings).ToArray());
        var items = await db.SyncQueueSet.Where(x => x.Status == SyncStatus.Failed).ToListAsync(cancellationToken);
        foreach (var item in items) { item.Status = SyncStatus.Pending; item.NextRetryAtUtc = DateTimeOffset.UtcNow; item.LastError = null; }
        await db.SaveChangesAsync(cancellationToken);
    }

    private SettingsDto Defaults(string row) => new(
        _options.Server.Port,
        _options.Server.UseHttps,
        _options.Discovery.Enabled,
        _options.Discovery.Port,
        paths.RootPath,
        _options.Storage.MinFreeBytes,
        _options.Transfer.ChunkSizeBytes,
        _options.Transfer.MaxConcurrentUploads,
        _options.Session.HeartbeatSeconds,
        _options.Session.DisconnectAfterSeconds,
        _options.Cloud.Enabled,
        _options.Retention.TemporaryHours,
        _options.Retention.LogsDays,
        row,
        _options.Cloud.SupabaseUrl,
        _options.Cloud.EffectivePublishableKey,
        _options.Cloud.OrganizationId,
        _options.Cloud.Environment,
        _options.Cloud.UseResumableUploads,
        !string.IsNullOrWhiteSpace(_options.Cloud.ResolveSecretKey()),
        _options.Cloud.Enabled ? "PendingPreflight" : "Disabled",
        _options.Cloud.AccessMode,
        cloud.Authenticated,
        cloud.CurrentSession?.Email);
    private SettingsDto OverlayCloudRuntime(SettingsDto value) =>
        value with
        {
            CloudEnabled = _options.Cloud.Enabled,
            SupabaseUrl = _options.Cloud.SupabaseUrl,
            SupabasePublishableKey = _options.Cloud.EffectivePublishableKey,
            OrganizationId = _options.Cloud.OrganizationId,
            CloudEnvironment = _options.Cloud.Environment,
            CloudUseResumableUploads = _options.Cloud.UseResumableUploads,
            CloudSecretConfigured = !string.IsNullOrWhiteSpace(
                _options.Cloud.ResolveSecretKey()),
            CloudConfigurationStatus = !_options.Cloud.Enabled
                ? "Disabled"
                : cloud.CanSynchronize
                    ? "Ready"
                    : cloud.Configured
                        ? "AuthenticationRequired"
                        : "NotConfigured",
            CloudAccessMode = _options.Cloud.AccessMode,
            CloudAuthenticated = cloud.Authenticated,
            CloudAuthenticatedEmail = cloud.CurrentSession?.Email
        };

    private static void Validate(UpdateSettingsRequest r)
    {
        if (r.ServerPort is < 1024 or > 65535 || r.DiscoveryPort is < 1024 or > 65535) throw new ApiException(ErrorCodes.ValidationFailed, "Cổng phải nằm trong 1024-65535.");
        if (r.ChunkSizeBytes is < 1048576 or > 16777216) throw new ApiException(ErrorCodes.ValidationFailed, "Chunk size phải từ 1 MiB đến 16 MiB.");
        if (r.HeartbeatSeconds is < 2 or > 60 || r.DisconnectAfterSeconds <= r.HeartbeatSeconds)
            throw new ApiException(ErrorCodes.ValidationFailed, "Cấu hình heartbeat không hợp lệ.");
        if (r.CloudEnabled)
        {
            if (!CloudAccessModes.IsValid(r.CloudAccessMode))
                throw new ApiException(
                    ErrorCodes.ValidationFailed,
                    "Cloud access mode phải là UserSession hoặc TrustedServer.");
            if (!Uri.TryCreate(r.SupabaseUrl, UriKind.Absolute, out var uri)
                || (uri.Scheme != Uri.UriSchemeHttps && !uri.IsLoopback))
                throw new ApiException(ErrorCodes.ValidationFailed, "Supabase URL phải là HTTPS hợp lệ.");
            if (string.IsNullOrWhiteSpace(r.SupabasePublishableKey))
                throw new ApiException(ErrorCodes.ValidationFailed, "Thiếu Supabase publishable key.");
            if (!Guid.TryParse(r.OrganizationId, out _))
                throw new ApiException(ErrorCodes.ValidationFailed, "Organization ID phải là UUID hợp lệ.");
            if (string.IsNullOrWhiteSpace(r.CloudEnvironment))
                throw new ApiException(ErrorCodes.ValidationFailed, "Cloud environment không được để trống.");
        }
    }
    private static string Version() => Assembly.GetEntryAssembly()?.GetName().Version?.ToString() ?? "1.0.0";
}
